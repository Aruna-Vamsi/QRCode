//
//  ViewController.swift
//  QRCode
//
//  Created by prominere on 01/08/20.
//  Copyright © 2020 QRCode. All rights reserved.
//

import UIKit
import CoreImage.CIFilterBuiltins

class ViewController: UIViewController {

    
    let context = CIContext()
    let filter = CIFilter.qrCodeGenerator()
    @IBOutlet  var qrcodeImage : UIImageView!
    @IBOutlet  var refreshData : UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        let timer = Timer.scheduledTimer(timeInterval: 20.0, target: self, selector: #selector(qrcode), userInfo: nil, repeats: true)
        self.qrcode()
        // Do any additional setup after loading the view.
    }

    @objc func qrcode()
    {
        let number = Int.random(in: 10000000 ... 20000000)
        qrcodeImage.image = generateQRCode(from: NSString(format: "%d", number) as String)
        refreshData.text = NSString(format: "QRCode %d \n %@", number, NSDate()) as String
    }
    func generateQRCode(from string: String) -> UIImage {
         let data = string.data(using: String.Encoding.ascii)

          if let filter = CIFilter(name: "CIQRCodeGenerator") {
              filter.setValue(data, forKey: "inputMessage")
              let transform = CGAffineTransform(scaleX: 10, y: 10)

              if let output = filter.outputImage?.transformed(by: transform) {
                  return UIImage(ciImage: output)
              }
          }
        return UIImage(systemName: "xmark.circle") ?? UIImage()
    }
    
}

